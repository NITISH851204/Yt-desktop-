package com.ytdesk.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var music: WebView
    @Volatile private var saver = false

    private val desktopUA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        saver = prefs.getBoolean("saver", false)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val btn = Button(this)
        fun label() { btn.text = if (saver) "Data Saver: ON" else "Data Saver: OFF" }
        label()
        btn.setOnClickListener {
            saver = !saver
            prefs.edit().putBoolean("saver", saver).apply()
            label()
            music.reload()
        }
        music = makeWeb("https://music.youtube.com")
        music.setBackgroundColor(Color.BLACK)
        root.addView(btn)
        root.addView(music, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, PlayerService::class.java))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(url: String): WebView = WebView(this).apply {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = desktopUA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(this, true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(this, AdBlock.KEEP_ALIVE_JS, setOf("https://*.youtube.com"))
        }
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString()
                return if (AdBlock.isAd(u) || (saver && AdBlock.isImage(u)))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }
            override fun onPageStarted(v: WebView, u: String?, f: android.graphics.Bitmap?) {
                v.evaluateJavascript(AdBlock.KEEP_ALIVE_JS, null)
            }
            override fun onPageFinished(v: WebView, u: String?) {
                v.evaluateJavascript("window.__ytdSaver=" + saver + ";", null)
                v.evaluateJavascript(AdBlock.JS, null)
            }
        }
        loadUrl(url)
    }

    // No WebView.onPause() on purpose, so music keeps playing in background.

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (music.canGoBack()) music.goBack() else moveTaskToBack(true)
    }

    override fun onDestroy() {
        stopService(Intent(this, PlayerService::class.java))
        music.destroy()
        super.onDestroy()
    }
}

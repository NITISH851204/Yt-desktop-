package com.ytdesk.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var panes: LinearLayout
    private lateinit var video: WebView
    private lateinit var music: WebView

    private val desktopUA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, mode: Int) = Button(this).apply {
            text = label
            setOnClickListener { setMode(mode) }
            bar.addView(this, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        btn("Video + Music", 0); btn("Video", 1); btn("Music", 2)

        panes = LinearLayout(this)
        video = makeWeb("https://www.youtube.com")
        music = makeWeb("https://music.youtube.com")
        panes.addView(video); panes.addView(music)

        root.addView(bar)
        root.addView(panes, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        applyOrientation()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, PlayerService::class.java))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(url: String): WebView = WebView(this).apply {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = desktopUA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true); setAcceptThirdPartyCookies(this@apply, true)
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(this, AdBlock.KEEP_ALIVE_JS, setOf("https://*.youtube.com"))
        }
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                return if (AdBlock.isAd(r.url.toString()))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }
            override fun onPageStarted(v: WebView, u: String?, f: android.graphics.Bitmap?) {
                v.evaluateJavascript(AdBlock.KEEP_ALIVE_JS, null)
            }
            override fun onPageFinished(v: WebView, u: String?) {
                v.evaluateJavascript(AdBlock.JS, null)
            }
        }
        loadUrl(url)
    }

    private fun setMode(m: Int) {
        video.visibility = if (m == 2) View.GONE else View.VISIBLE
        music.visibility = if (m == 1) View.GONE else View.VISIBLE
    }

    private fun applyOrientation() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        panes.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        for (w in listOf(video, music)) {
            w.layoutParams = if (land) LinearLayout.LayoutParams(0, -1, 1f) else LinearLayout.LayoutParams(-1, 0, 1f)
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c); applyOrientation()
    }

    // Intentionally no WebView.onPause() here, so audio keeps playing in background.

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            video.visibility == View.VISIBLE && video.canGoBack() -> video.goBack()
            music.visibility == View.VISIBLE && music.canGoBack() -> music.goBack()
            else -> moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        stopService(Intent(this, PlayerService::class.java))
        video.destroy(); music.destroy()
        super.onDestroy()
    }
}

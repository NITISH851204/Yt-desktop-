package com.ytdesk.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var music: WebView
    private lateinit var offline: LinearLayout
    private lateinit var nowPlaying: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private val uris = mutableListOf<Uri>()
    private val names = mutableListOf<String>()
    private var player: MediaPlayer? = null
    private var index = -1

    private val desktopUA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { res ->
        for (u in res) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
            if (!uris.contains(u)) { uris.add(u); names.add(nameOf(u)) }
        }
        adapter.notifyDataSetChanged()
        save()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabMusic = Button(this).apply { text = "YT Music"; setOnClickListener { showOffline(false) } }
        val tabOffline = Button(this).apply { text = "Offline Music"; setOnClickListener { showOffline(true) } }
        bar.addView(tabMusic, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(tabOffline, LinearLayout.LayoutParams(0, -2, 1f))

        music = makeWeb("https://music.youtube.com")
        load()
        offline = buildOffline()
        offline.visibility = View.GONE

        val frame = FrameLayout(this)
        frame.addView(music, FrameLayout.LayoutParams(-1, -1))
        frame.addView(offline, FrameLayout.LayoutParams(-1, -1))

        root.addView(bar)
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        ContextCompat.startForegroundService(this, Intent(this, PlayerService::class.java))
    }

    private fun showOffline(on: Boolean) {
        offline.visibility = if (on) View.VISIBLE else View.GONE
        music.visibility = if (on) View.GONE else View.VISIBLE
        if (!on) player?.let { if (it.isPlaying) it.pause() }
    }

    private fun buildOffline(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val add = Button(this).apply {
            text = "+ Phone se songs jodo"
            setOnClickListener { picker.launch(arrayOf("audio/*")) }
        }
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        val lv = ListView(this)
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ -> play(pos) }
        lv.setOnItemLongClickListener { _, _, pos, _ -> remove(pos); true }

        nowPlaying = TextView(this).apply {
            setTextColor(Color.WHITE); setPadding(24, 16, 24, 16)
            text = "Song dabao (lamba dabao = hatao)"
        }
        val ctrl = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val prev = Button(this).apply { text = "⏮"; setOnClickListener { step(-1) } }
        val pp = Button(this).apply { text = "⏯"; setOnClickListener { toggle() } }
        val next = Button(this).apply { text = "⏭"; setOnClickListener { step(1) } }
        ctrl.addView(prev, LinearLayout.LayoutParams(0, -2, 1f))
        ctrl.addView(pp, LinearLayout.LayoutParams(0, -2, 1f))
        ctrl.addView(next, LinearLayout.LayoutParams(0, -2, 1f))

        box.addView(add)
        box.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        box.addView(nowPlaying)
        box.addView(ctrl)
        return box
    }

    private fun play(pos: Int) {
        if (pos !in uris.indices) return
        index = pos
        player?.release(); player = null
        try {
            val mp = MediaPlayer()
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setDataSource(this, uris[pos])
            mp.prepare()
            mp.setOnCompletionListener { play((index + 1) % uris.size) }
            mp.start()
            player = mp
            nowPlaying.text = "▶ " + names[pos]
        } catch (e: Exception) {
            Toast.makeText(this, "Ye song nahi chala", Toast.LENGTH_SHORT).show()
        }
    }

    private fun step(d: Int) {
        if (uris.isEmpty()) return
        play(((if (index < 0) 0 else index) + d + uris.size) % uris.size)
    }

    private fun toggle() {
        val p = player
        if (p == null) { if (uris.isNotEmpty()) play(if (index < 0) 0 else index) }
        else if (p.isPlaying) p.pause() else p.start()
    }

    private fun remove(pos: Int) {
        if (pos !in uris.indices) return
        if (pos == index) { player?.release(); player = null; index = -1; nowPlaying.text = "—" }
        else if (pos < index) index--
        uris.removeAt(pos); names.removeAt(pos)
        adapter.notifyDataSetChanged(); save()
    }

    private fun nameOf(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        } catch (e: Exception) { }
        return u.lastPathSegment ?: "song"
    }

    private fun save() {
        getSharedPreferences("lib", Context.MODE_PRIVATE).edit()
            .putString("uris", uris.joinToString("\n")).apply()
    }

    private fun load() {
        val s = getSharedPreferences("lib", Context.MODE_PRIVATE).getString("uris", "") ?: ""
        for (line in s.split("\n")) {
            if (line.isBlank()) continue
            val u = Uri.parse(line)
            uris.add(u); names.add(nameOf(u))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(url: String): WebView = WebView(this).apply {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = desktopUA
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
        }
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(this, true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(this, AdBlock.KEEP_ALIVE_JS, setOf("https://*.youtube.com"))
        }
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                return if (AdBlock.isAd(r.url.toString()))
                    WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                else null
            }
            override fun onPageStarted(v: WebView, u: String?, f: android.graphics.Bitmap?) {
                v.evaluateJavascript(AdBlock.KEEP_ALIVE_JS, null)
            }
            override fun onPageFinished(v: WebView, u: String?) {
                v.evaluateJavascript(AdBlock.JS, null)
            }
        }
        loadUrl(url)
    }

    // No WebView.onPause() on purpose, so music keeps playing in background.

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            offline.visibility == View.VISIBLE -> showOffline(false)
            music.canGoBack() -> music.goBack()
            else -> moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        player?.release()
        stopService(Intent(this, PlayerService::class.java))
        music.destroy()
        super.onDestroy()
    }
}

package com.ytdesk.app

object AdBlock {
    private val patterns = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "/pagead/", "/api/stats/ads", "/ptracking", "get_midroll_info", "ad_break"
    )

    fun isAd(url: String) = patterns.any { url.contains(it) }

    private val imageHosts = listOf(
        "lh3.googleusercontent.com", "i.ytimg.com", "yt3.ggpht.com", "yt3.googleusercontent.com"
    )

    // Data saver: album art / thumbnails are not loaded.
    fun isImage(url: String) = imageHosts.any { url.contains(it) }

    // Runs after page load: skips/fast-forwards video ads, hides ad boxes.
    const val JS = """
(function(){
 if(window.__ytd) return; window.__ytd=true;
 var css=document.createElement('style');
 css.textContent='.ytp-ad-overlay-container,#masthead-ad,ytd-ad-slot-renderer,ytd-promoted-sparkles-web-renderer,ytd-display-ad-renderer,ytd-banner-promo-renderer,#player-ads,.ytp-ad-module{display:none!important}';
 document.documentElement.appendChild(css);
 var wasAd=false, tick=0;
 var isMusic=location.hostname.indexOf('music.youtube.com')>-1;
 if(isMusic){
  var c2=document.createElement('style');
  c2.textContent='ytmusic-player video{visibility:hidden!important}';
  document.documentElement.appendChild(c2);
 }
 setInterval(function(){
  tick++;
  if(isMusic&&tick%6===0){
   var t=document.querySelector('ytmusic-av-toggle .song-button');
   if(t) t.click();
  }
  var v=document.querySelector('video');
  var ad=document.querySelector('.ad-showing');
  if(ad&&v){
    wasAd=true; v.muted=true; v.playbackRate=16;
    if(isFinite(v.duration)&&v.duration>0){v.currentTime=v.duration;}
  } else if(wasAd&&v){
    wasAd=false; v.muted=false; v.playbackRate=1;
  }
  if(window.__ytdSaver&&tick%6===0){
   var pl=document.getElementById('movie_player');
   if(pl&&pl.setPlaybackQualityRange){ try{pl.setPlaybackQualityRange('tiny','tiny');}catch(e){} }
  }
  var s=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern');
  if(s) s.click();
 },300);
})();
"""

    // Makes the page think it is always visible so playback continues in background.
    const val KEEP_ALIVE_JS = """
(function(){
 try{
  Object.defineProperty(document,'hidden',{get:function(){return false},configurable:true});
  Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'},configurable:true});
  document.addEventListener('visibilitychange',function(e){e.stopImmediatePropagation()},true);
  window.addEventListener('blur',function(e){e.stopImmediatePropagation()},true);
 }catch(e){}
})();
"""
}
